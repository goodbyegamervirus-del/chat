# "Talking to a 13 year old in 2016" Simulator

A Pen created on CodePen.

Original URL: [https://codepen.io/Flipybitz/pen/xZLZLq](https://codepen.io/Flipybitz/pen/xZLZLq).

A small funny thing I threw together to simulate talking to a 10 year old kid on the internet! None of the language included is meant to be offensive towards anyone and is purely satire.

2024 EDIT: Reflecting back, I wrote this when I was an 'edgy 17 year old 4chan user' and had just dropped out of high school, despite being full of passion and being unsure where to funnel any of it... LONG story short, I'm a trans furry now funny enough, and I want to leave this completely untouched... I see it as a really fascinating time capsule into my brain in 2016 when I just played garrys mod and counter-strike, and this encapsulates how I viewed interactions with people younger than me! (P.S. YES I SEE THIS GETTING LOTS OF VIEWS AND COMMENTS, 77K SO FAR, BUT WHY??? WTF DO ANY OF YOU GET OUT OF INTERACTING WITH THIS?)